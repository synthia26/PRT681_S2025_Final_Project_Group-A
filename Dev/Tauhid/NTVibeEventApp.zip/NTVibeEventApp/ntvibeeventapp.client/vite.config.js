﻿import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url'; 

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      // ✅ Module Resolution Fixes (already added)
      'prop-types': fileURLToPath(new URL('./node_modules/prop-types', import.meta.url)),
      'react-transition-group': fileURLToPath(new URL('./node_modules/react-transition-group', import.meta.url)),
     
      // 🛑 MULTIPLE REACT COPIES FIX 🛑
      // These aliases force Kendo to use the top-level React installation
      'react': fileURLToPath(new URL('./node_modules/react', import.meta.url)),
      'react-dom': fileURLToPath(new URL('./node_modules/react-dom', import.meta.url)),
      'react-router-dom': fileURLToPath(new URL('./node_modules/react-router-dom', import.meta.url)),
    },
  },
});