﻿import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import RegisterForm from "./components/RegisterForm";
import LoginForm from "./components/LoginForm";
import EventDetailPage from "./pages/Events"; // <-- NEW IMPORT

// =================================================================
// ⚠️ ACTION: Keep this set to 'false'
const USE_KENDO_EVENTS = true; 
// =================================================================

// ❌ COMMENT OUT THIS LINE ENTIRELY ❌
// The import statement itself is what breaks the build.
// import Events from "./components/EventList"; 


// Placeholder component (no change needed here)
const EventsPlaceholder = () => (
    <div style={{ 
        padding: '20px', 
        margin: '20px', 
        border: '2px solid red', 
        color: 'red', 
        backgroundColor: '#fee',
        fontWeight: 'bold' 
    }}>
        ⚠️ EVENTS COMPONENT DISABLED ⚠️
        <p style={{ fontWeight: 'normal', marginTop: '10px' }}>
            The Event List component is temporarily disabled to bypass the Kendo build error.
        </p>
    </div>
);


export default function App() {
    return (
        <Router>
            <nav style={{ padding: '10px', backgroundColor: '#f0f0f0', display: 'flex', gap: '15px' }}>
                <Link to="/" className="text-blue-600 hover:text-blue-800">Home</Link>
                <Link to="/register" className="text-blue-600 hover:text-blue-800">Register</Link>
                <Link to="/login" className="text-blue-600 hover:text-blue-800">Login</Link>
                <Link to="/events" className="text-blue-600 hover:text-blue-800">Events</Link>
            </nav>

            <div className="p-4">
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/register" element={<RegisterForm />} />
                    <Route path="/login" element={<LoginForm />} />
                    
                    {/* NEW: Route for the specific event detail page, using a dynamic ID parameter */}
                    <Route path="/event/:id" element={<EventDetailPage />} />

                    {/* Events List Placeholder Route (Kept for compatibility) */}
                    <Route 
                        path="/events" 
                        element={USE_KENDO_EVENTS ? null : <EventsPlaceholder />} 
                    />
                </Routes>
            </div>
        </Router>
    );
}
