﻿import React, { useState } from 'react';
// 💡 Import the specific review service
// FIX: Adding the explicit .js extension again. If this fails, please ensure
// that 'apiService.js' is saved directly inside a folder named 'services',
// and that 'ReviewForm.jsx' is saved directly inside a folder named 'components',
// and both 'services' and 'components' are siblings under the 'src' directory.
import { reviewService } from '../services/apiService.js'; 

// Assume this component is used on an Event Detail Page
function ReviewForm({ eventId, onReviewSubmitted }) {
    const [rating, setRating] = useState(5);
    const [comment, setComment] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        // IMPORTANT: We should implement an auth check here before submitting
        // For now, the backend will handle the 401/403 response if not logged in.
        
        setIsSubmitting(true);
        const reviewData = { rating, comment };
        
        try {
            // 📞 Call the POST service method from apiService.js
            await reviewService.postReview(eventId, reviewData);

            // Using console.log instead of alert for better UX
            console.log("Review submitted successfully!");
            setComment(''); // Clear the form
            // Notify the parent page to refresh the list of reviews
            onReviewSubmitted(); 
        } catch (error) {
            console.error("Review submission failed:", error.response?.data);
            // Replaced alert with a custom message box or visible UI error in a production app
            const msg = error.response?.data?.message || "Login required or error submitting review.";
            alert(msg); // Keeping alert for simplicity in this environment
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="p-6 bg-white rounded-xl shadow-lg border border-indigo-100">
            <h4 className="text-xl font-bold mb-4 text-indigo-700">Submit Your Review</h4>
            
            <div className="mb-4">
                <label htmlFor="rating" className="block text-sm font-medium text-gray-700">Rating (1-5 Stars)</label>
                <input
                    id="rating"
                    type="number"
                    min="1"
                    max="5"
                    value={rating}
                    onChange={(e) => setRating(parseInt(e.target.value))}
                    className="mt-1 block w-20 p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                    required
                />
            </div>
            
            <div className="mb-4">
                <label htmlFor="comment" className="block text-sm font-medium text-gray-700">Your Comment</label>
                <textarea
                    id="comment"
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Tell the Darwin community about your experience..."
                    rows="3"
                    className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                    required
                ></textarea>
            </div>
            
            <button 
                type="submit" 
                disabled={isSubmitting}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
                {isSubmitting ? 'Sending Review...' : 'Post Review'}
            </button>
        </form>
    );
}

export default ReviewForm;
