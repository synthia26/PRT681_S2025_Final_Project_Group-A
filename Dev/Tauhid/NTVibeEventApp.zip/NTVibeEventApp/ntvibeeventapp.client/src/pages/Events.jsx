import React from "react";
import EventList from "../components/EventList";

export default function Events() {
    return (
        <div style={{ padding: "24px" }}>
            <EventList />
        </div>
    );
}
