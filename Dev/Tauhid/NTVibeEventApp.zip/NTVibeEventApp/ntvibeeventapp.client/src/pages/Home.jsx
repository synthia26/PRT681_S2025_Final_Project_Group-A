﻿import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom"; // Import Link for navigation
import {
    Card,
    CardHeader,
    CardBody,
    CardTitle,
    CardActions
} from "@progress/kendo-react-layout";

// 💡 Import the necessary services from your communication hub
// Assuming apiService.js is in src/services/
import { categoryService, eventService } from "../services/apiService.jsx";

export default function Home() {
    // State for Search and Filter
    const [searchTerm, setSearchTerm] = useState("");
    const [selectedCategory, setSelectedCategory] = useState("");
    
    // State for Data
    const [events, setEvents] = useState([]);
    const [categories, setCategories] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    // --- EFFECT 1: Fetch Categories (Runs only once on load) ---
    useEffect(() => {
        const fetchCategories = async () => {
            try {
                // Calls: GET /api/categories
                const response = await categoryService.getCategories();
                // Assumes categories is an array of CategoryDto { id, name }
                setCategories(response.data || []);
            } catch (err) {
                console.error("Failed to fetch categories:", err);
            }
        };
        fetchCategories();
    }, []);


    // --- EFFECT 2: Fetch and Search Events (Runs on load or when filter changes) ---
    useEffect(() => {
        const fetchEvents = async () => {
            setIsLoading(true);
            setError(null);
            try {
                // Calls: GET /api/events/search?searchTerm=...&categoryId=...
                const response = await eventService.searchEvents(
                    searchTerm, 
                    selectedCategory
                );
                setEvents(response.data || []);
            } catch (err) {
                console.error("Failed to fetch events:", err);
                setError("Could not load events. Please check the backend API.");
                setEvents([]);
            } finally {
                setIsLoading(false);
            }
        };

        // Debounce or immediate fetch logic can be added here, 
        // but for simplicity, we fetch immediately on change.
        fetchEvents();
    }, [searchTerm, selectedCategory]); // Dependencies: Refetch when search term or category changes


    const handleSearchSubmit = (e) => {
        e.preventDefault();
        // The search term is already updated via the input onChange, 
        // and the useEffect will automatically trigger the API call.
        // We only need to prevent the default form submission behavior here.
    };

    const handleCategoryChange = (e) => {
        // Update state, triggering the useEffect to fetch new events
        setSelectedCategory(e.target.value);
    };

    return (
        <div
            style={{
                minHeight: "100vh",
                display: "flex",
                flexDirection: "column",
                background: "linear-gradient(135deg, #E95420, #FFB347)",
                color: "white",
                fontFamily: "Inter, sans-serif",
            }}
        >
            {/* Top Menu: Fixed <a> tags to use Link for client-side routing */}
            <header
                style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "15px 30px",
                    backgroundColor: "rgba(0,0,0,0.2)",
                }}
            >
                <h2 style={{ margin: 0 }}>🌴 NT Vibe</h2>
                {/* 💡 FIX: Using Link components for navigation */}
                <nav style={{ display: 'flex', gap: '20px' }}>
                    <Link to="/" style={{ color: "white" }}>Home</Link>
                    <Link to="/register" style={{ color: "white" }}>Register</Link>
                    <Link to="/login" style={{ color: "white" }}>Login</Link>
                    <Link to="/events" style={{ color: "white" }}>Events List</Link>
                </nav>
            </header>

            {/* Main Content */}
            <main style={{ flex: 1, textAlign: "center", padding: "40px" }}>
                <h1 style={{ fontSize: "3rem", marginBottom: "20px" }}>
                    Darwin Event Discoverer
                </h1>
                <p style={{ fontSize: "1.2rem", maxWidth: "700px", margin: "0 auto 30px" }}>
                    Discover events, connect with the community, and enjoy the Top End!
                </p>

                {/* Search and Filter Section */}
                <div style={{ display: 'flex', justifyContent: 'center', gap: '15px', marginBottom: "40px" }}>
                    
                    {/* Category Filter Dropdown */}
                    <select
                        onChange={handleCategoryChange}
                        value={selectedCategory}
                        style={{
                            padding: "10px",
                            borderRadius: "5px",
                            border: "none",
                            color: "#333",
                            backgroundColor: "white",
                        }}
                    >
                        <option value="">All Categories</option>
                        {categories.map(cat => (
                            <option key={cat.id} value={cat.id}>
                                {cat.name}
                            </option>
                        ))}
                    </select>

                    {/* Search Bar */}
                    <form onSubmit={handleSearchSubmit} style={{ display: 'flex' }}>
                        <input
                            type="text"
                            placeholder="Search events by title or location..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            style={{
                                padding: "10px",
                                width: "300px",
                                borderRadius: "5px 0 0 5px",
                                border: "none",
                                color: "#333",
                            }}
                        />
                        <button
                            type="submit"
                            style={{
                                padding: "10px 20px",
                                border: "none",
                                backgroundColor: "#006400",
                                color: "white",
                                borderRadius: "0 5px 5px 0",
                                cursor: "pointer",
                            }}
                        >
                            <span role="img" aria-label="Search">🔍</span>
                        </button>
                    </form>
                </div>


                {/* Event Cards */}
                <div style={{ display: "flex", gap: "20px", justifyContent: "center", flexWrap: "wrap" }}>
                    {isLoading && <p>Loading Darwin events...</p>}
                    {error && <p style={{ color: 'red' }}>Error: {error}</p>}
                    {!isLoading && events.length === 0 && <p>No events found matching your criteria.</p>}
                    
                    {events.map((event) => (
                        // Assume event object has { id, title, description, date, location, image }
                        <Card key={event.id} style={{ width: 300, color: '#333', textAlign: 'left' }}>
                            <CardHeader>
                                <img
                                    src={event.image || `https://placehold.co/300x150/f0f0f0/333333?text=${encodeURIComponent(event.title)}`}
                                    alt={event.title}
                                    style={{ width: "100%", height: "150px", objectFit: 'cover', borderRadius: "6px 6px 0 0" }}
                                    onError={(e) => { e.target.onerror = null; e.target.src = "https://placehold.co/300x150/f0f0f0/333333?text=NT+Event"; }}
                                />
                            </CardHeader>
                            <CardBody>
                                <CardTitle style={{ color: '#E95420' }}>{event.title}</CardTitle>
                                <p style={{ fontSize: "0.9rem", margin: "10px 0" }}>{event.description}</p>
                                <p style={{ marginBottom: '5px' }}><strong>Date:</strong> {new Date(event.date).toDateString()}</p>
                                <p><strong>Location:</strong> {event.location}</p>
                            </CardBody>
                            <CardActions>
                                {/* 💡 FIX: Using Link to navigate to the Event Detail Page */}
                                <Link to={`/event/${event.id}`}>
                                    <button
                                        style={{
                                            background: "#007bff",
                                            color: "white",
                                            padding: "8px 14px",
                                            border: "none",
                                            borderRadius: "4px",
                                            cursor: "pointer",
                                        }}
                                    >
                                        View Details
                                    </button>
                                </Link>
                            </CardActions>
                        </Card>
                    ))}
                </div>

                {/* Explore More Button (now purely decorative or can be removed) */}
                <button
                    style={{
                        padding: "12px 24px",
                        fontSize: "1rem",
                        fontWeight: "bold",
                        backgroundColor: "#006400",
                        color: "white",
                        border: "none",
                        borderRadius: "8px",
                        cursor: "pointer",
                        marginTop: "30px"
                    }}
                >
                    Explore More
                </button>
            </main>
        </div>
    );
}
