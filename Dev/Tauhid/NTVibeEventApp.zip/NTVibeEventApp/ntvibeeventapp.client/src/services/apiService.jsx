// C:\Users\atoul\source\repos\...\src\services\apiService.jsx (CORRECTED)

import axios from 'axios';

// 1. The BASE URL: Tells the waiter where the kitchen is located.
// This is your .NET Core API address (Port 7125)
const API_URL = 'https://localhost:7125/api';

// Create an instance of Axios (a tool for making API calls)
const api = axios.create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json',
    },
    withCredentials: true,
});

// 2. The INTERCEPTOR: The waiter's rulebook.
// Before sending ANY request, this rule ensures the user's login token�
// (which we store in localStorage) is attached for security.
api.interceptors.request.use(config => {
    const token = localStorage.getItem('authToken');
    if (token) {
        // If a token exists, add it to the 'Authorization' header
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
}, error => {
    return Promise.reject(error);
});

// =================================================================
// 3. SERVICE DEFINITIONS: The Waiter's Menu of Functions
// =================================================================

// 3A. Category Service (New API 1: Public Read)
export const categoryService = {
    // getCategories: asks the kitchen for the list of categories.
    // Maps to: GET https://localhost:7125/api/categories
    getCategories: () => api.get('/categories'),
};

// 3B. Review Service (New API 2: Authenticated Write & Read)
export const reviewService = {
    // postReview: sends a new review for a specific eventId.�
    // Maps to: POST https://localhost:7125/api/events/{eventId}/reviews
    postReview: (eventId, reviewData) => api.post(`/events/${eventId}/reviews`, reviewData),

    // getReviewsForEvent: gets all reviews for an event.
    // Maps to: GET https://localhost:7125/api/events/{eventId}/reviews
    getReviewsForEvent: (eventId) => api.get(`/events/${eventId}/reviews`),
};


// 3C. Event Service (THE MISSING SERVICE)
// This must be exported with the name 'eventService' to resolve the error.
export const eventService = {
    // getEvents: fetches a list of events.
    // Maps to: GET https://localhost:7125/api/events
    getEvents: () => api.get('/events'),

    // getEventDetail: fetches a single event by ID.
    // Maps to: GET https://localhost:7125/api/events/{id}
    getEventDetail: (id) => api.get(`/events/${id}`),

    // deleteEvent: (Requires Authorization)
    // Maps to: DELETE https://localhost:7125/api/events/{id}
    deleteEvent: (id) => api.delete(`/events/${id}`)

    // Add any other event-related functions (like createEvent, updateEvent, etc.) here.
};


// (You would add your existing authService here too, likely as an export like the others!)
export default api;