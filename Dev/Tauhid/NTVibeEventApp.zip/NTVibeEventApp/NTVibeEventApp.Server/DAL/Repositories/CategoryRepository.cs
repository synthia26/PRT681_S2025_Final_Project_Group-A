using Microsoft.EntityFrameworkCore;
using NTVibeEventApp.Server.DAL.Context;
using NTVibeEventApp.Server.DAL.Interfaces;
using NTVibeEventApp.Server.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NTVibeEventApp.Server.DAL.Repositories
{
    // Implementation of the ICategoryRepository interface
    public class CategoryRepository : ICategoryRepository
    {
        private readonly ApplicationDbContext _context;

        // Dependency Injection to get the database context
        public CategoryRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Retrieves all Category entities from the database.
        /// </summary>
        /// <returns>A collection of Category entities.</returns>
        public async Task<IEnumerable<Category>> GetAllAsync()
        {
            // Simple retrieval of all Category entities
            return await _context.Categories
                                 .AsNoTracking() // Use AsNoTracking for read-only operations
                                 .ToListAsync();
        }
    }
}
