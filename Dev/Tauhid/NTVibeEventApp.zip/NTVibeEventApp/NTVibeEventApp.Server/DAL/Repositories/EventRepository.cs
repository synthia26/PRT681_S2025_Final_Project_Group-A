﻿namespace NTVibeEventApp.Server.DAL.Repositories
{
    public class EventRepository
    {
    }
}
