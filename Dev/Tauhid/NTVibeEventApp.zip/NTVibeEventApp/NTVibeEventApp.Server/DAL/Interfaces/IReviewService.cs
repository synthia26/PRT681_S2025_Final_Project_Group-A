using System.Collections.Generic;
using System.Threading.Tasks;
using NTVibeEventApp.Server.Presentation.DTOs;

namespace NTVibeEventApp.Server.BLL.Interfaces
{
    // Defines the contract for review-related business logic operations.
    public interface IReviewService
    {
        /// <summary>
        /// Retrieves all reviews for a specific event.
        /// </summary>
        /// <param name="eventId">The ID of the event.</param>
        /// <returns>A list of review details for the specified event.</returns>
        Task<IEnumerable<ReviewDetailsDto>> GetReviewsForEventAsync(int eventId);

        /// <summary>
        /// Creates a new review for an event.
        /// </summary>
        /// <param name="reviewDto">The DTO containing the new review data.</param>
        /// <returns>The created review details.</returns>
        Task<ReviewDetailsDto> CreateReviewAsync(CreateReviewDto reviewDto);
    }
}
