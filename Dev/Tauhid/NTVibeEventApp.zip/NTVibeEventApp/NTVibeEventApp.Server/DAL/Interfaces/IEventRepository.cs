﻿namespace NTVibeEventApp.Server.DAL.Interfaces
{
    public class IEventRepository
    {
    }
}
