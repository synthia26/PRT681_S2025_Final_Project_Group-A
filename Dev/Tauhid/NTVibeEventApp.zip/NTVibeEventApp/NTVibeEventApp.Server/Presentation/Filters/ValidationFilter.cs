﻿namespace NTVibeEventApp.Server.Presentation.Filters
{
    public class ValidationFilter
    {
    }
}
