﻿namespace NTVibeEventApp.Server.Presentation.DTOs
{
    public class EventDto
    {
    }
}
