// DTO used to transfer category data from the backend to the frontend.
// It excludes complex navigation properties (like the list of Events) 
// for clean data transfer.
public class CategoryDto
{
    /// <summary>
    /// Unique identifier for the category.
    /// </summary>
    public int Id { get; set; }
    
    /// <summary>
    /// The display name of the category (e.g., "Music", "Workshop").
    /// </summary>
    public string Name { get; set; }
    
    /// <summary>
    /// Optional class name for a frontend icon associated with the category.
    /// </summary>
    public string IconClass { get; set; }
}
