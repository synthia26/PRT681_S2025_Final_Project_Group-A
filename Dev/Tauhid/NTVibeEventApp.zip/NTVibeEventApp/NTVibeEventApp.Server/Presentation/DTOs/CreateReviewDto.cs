// DTO used for posting a new review from the frontend.
public class CreateReviewDto
{
    // Required: Must be between 1 and 5 (or your chosen range)
    public int Rating { get; set; } 
    
    // Optional: The textual comment/feedback
    public string Comment { get; set; }
}
