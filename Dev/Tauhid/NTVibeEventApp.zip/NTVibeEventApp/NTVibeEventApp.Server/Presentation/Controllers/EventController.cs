using Microsoft.AspNetCore.Mvc;

namespace NTVibeEventApp.Server.Presentation.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EventController : ControllerBase
    {
        
    }
}
