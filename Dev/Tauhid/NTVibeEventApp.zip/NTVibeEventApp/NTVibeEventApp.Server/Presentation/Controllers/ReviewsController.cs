﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic; // Required for IEnumerable
using System.Threading.Tasks; // Required for Task
using NTVibeEventApp.Server.Presentation.DTOs; // CORRECT: DTOs are here
using NTVibeEventApp.Server.BLL.Interfaces; 

namespace NTVibeEventApp.Server.Presentation.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReviewsController : ControllerBase
    {
        // Use an injected service for business logic
        private readonly IReviewService _reviewService; 

        // Assume IReviewService is registered in Program.cs
        public ReviewsController(IReviewService reviewService) 
        {
            _reviewService = reviewService;
        }

        // POST /api/reviews
        [HttpPost]
        public async Task<IActionResult> PostReview([FromBody] CreateReviewDto reviewDto)
        {
            // Call service to validate, map, and save the review
            var newReview = await _reviewService.CreateReviewAsync(reviewDto);
            
            // Return 201 Created status
            return StatusCode(201, newReview); 
        }

        // GET /api/reviews/{eventId}
        [HttpGet("{eventId}")]
        public async Task<ActionResult<IEnumerable<ReviewDetailsDto>>> GetReviews(int eventId)
        {
            // Assuming ReviewDetailsDto is the DTO returned for fetching reviews
            var reviews = await _reviewService.GetReviewsForEventAsync(eventId);

            // You will need a ReviewDetailsDto defined to return comprehensive review data
            return Ok(reviews);
        }
    }
}
