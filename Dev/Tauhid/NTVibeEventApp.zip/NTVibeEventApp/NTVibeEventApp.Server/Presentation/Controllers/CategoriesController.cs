using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks; // <-- ADDED: Required for async/Task
using System.Collections.Generic; // <-- ADDED: Required for IEnumerable
using NTVibeEventApp.Server.BLL.Interfaces; 
using NTVibeEventApp.Server.Presentation.DTOs; 

namespace NTVibeEventApp.Server.Presentation.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CategoriesController : ControllerBase
    {
        private readonly ICategoryService _categoryService;

        public CategoriesController(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        // GET /api/categories
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CategoryDto>>> GetCategories()
        {
            // Call the service layer to get the data
            var categories = await _categoryService.GetAllCategoriesAsync();

            // NOTE: In a complete application, you would map the entity (Category) 
            // to a DTO (CategoryDto) here before returning.
            // Assuming your service returns CategoryDto for simplicity now.
            return Ok(categories);
        }

        // Add other category endpoints (e.g., GetCategoryById) as needed
    }
}
