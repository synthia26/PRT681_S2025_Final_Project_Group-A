﻿namespace NTVibeEventApp.Server.Entities
{
    public class Event
    {
    }
}
