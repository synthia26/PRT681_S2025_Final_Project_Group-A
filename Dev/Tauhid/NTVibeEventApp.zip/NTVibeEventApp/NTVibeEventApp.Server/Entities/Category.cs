﻿// Assuming this is your Category entity file
using System.Collections.Generic;
using NTVibeEventApp.Server.Entities; // Assuming Event is here

namespace NTVibeEventApp.Server.Entities
{
    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }

        // Navigation property for Events
        public ICollection<Event> Events { get; set; } = new List<Event>();
    }
}
