﻿// Represents a user's rating and text review for an event.
public class Review
{
    public int Id { get; set; }
    
    // Rating out of 5 stars (or similar scale)
    public int Rating { get; set; } 
    public string Comment { get; set; }
    public DateTime DateSubmitted { get; set; } = DateTime.UtcNow;

    // Foreign Key for the User who wrote the review
    public string UserId { get; set; } 
    // public User User { get; set; } // Assuming User model exists
    
    // Foreign Key for the Event being reviewed
    public int EventId { get; set; }
    // public Event Event { get; set; } // Assuming Event model exists
}

// ⚠️ Ensure you add: public DbSet<Review> Reviews { get; set; } 
// to your ApplicationDbContext and run migrations.
