using NTVibeEventApp.Server.BLL.Interfaces;
using NTVibeEventApp.Server.Presentation.DTOs;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NTVibeEventApp.Server.BLL.Services
{
    // Make sure this file is created in your BLL/Services folder
    public class CategoryService : ICategoryService
    {
        private readonly ICategoryRepository _categoryRepository;

        // Dependency Injection of the repository
        public CategoryService(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

        public async Task<IEnumerable<CategoryDto>> GetAllCategoriesAsync()
        {
            // 1. Fetch the raw Category entities from the database via the repository
            var categories = await _categoryRepository.GetAllAsync();

            // 2. Map the entities (Category) to the DTOs (CategoryDto)
            var categoryDtos = categories.Select(c => new CategoryDto
            {
                Id = c.Id,
                Name = c.Name
                // You can add more properties here if they exist on the Category entity
            }).ToList();

            return categoryDtos;
        }
    }
}
