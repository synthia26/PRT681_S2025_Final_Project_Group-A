﻿namespace NTVibeEventApp.Server.BLL.Services
{
    public class EventService
    {
    }
}
