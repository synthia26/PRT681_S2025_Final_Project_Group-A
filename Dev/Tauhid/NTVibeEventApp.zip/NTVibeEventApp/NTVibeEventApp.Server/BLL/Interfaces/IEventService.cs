﻿namespace NTVibeEventApp.Server.BLL.Interfaces
{
    public class IeventService
    {
    }
}
